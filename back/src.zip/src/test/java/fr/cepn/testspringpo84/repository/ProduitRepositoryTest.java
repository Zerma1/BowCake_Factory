package fr.cepn.testspringpo84.repository;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ProduitRepositoryTest {

    @Test
    void findByTypeProduit() {
    }
}