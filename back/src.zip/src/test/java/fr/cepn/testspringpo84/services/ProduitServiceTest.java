package fr.cepn.testspringpo84.services;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ProduitServiceTest {

    @Test
    void findByTypeProduit() {
    }
}