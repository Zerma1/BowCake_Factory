package fr.cepn.testspringpo84.models;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class userTest {

    @Test
    void testEquals() {
    }

    @Test
    void canEqual() {
    }

    @Test
    void testHashCode() {
    }

    @Test
    void testToString() {
    }

    @Test
    void getNom() {
    }

    @Test
    void getRole() {
    }

    @Test
    void getEmail() {
    }

    @Test
    void getTelephon() {
    }

    @Test
    void getPoints() {
    }

    @Test
    void setEmail() {
    }

    @Test
    void setTelephon() {
    }

    @Test
    void setPoints() {
    }

    @Test
    void testEquals1() {
    }

    @Test
    void testCanEqual() {
    }

    @Test
    void testHashCode1() {
    }

    @Test
    void testToString1() {
    }

    @Test
    void testGetNom() {
    }

    @Test
    void testGetRole() {
    }

    @Test
    void testGetEmail() {
    }

    @Test
    void testGetTelephon() {
    }

    @Test
    void testGetPoints() {
    }

    @Test
    void testSetEmail() {
    }

    @Test
    void testSetTelephon() {
    }

    @Test
    void testSetPoints() {
    }
}