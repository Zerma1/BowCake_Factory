package fr.cepn.testspringpo84.models.commons;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AbstractPersistableWithIdSetterTest {

    @Test
    void setId() {
    }
}