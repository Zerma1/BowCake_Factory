package fr.cepn.testspringpo84;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestSpringPo84ApplicationTests {

    @Test
    void contextLoads() {
    }

}
