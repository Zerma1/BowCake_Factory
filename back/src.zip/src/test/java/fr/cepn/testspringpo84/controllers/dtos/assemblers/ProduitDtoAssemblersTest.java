package fr.cepn.testspringpo84.controllers.dtos.assemblers;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ProduitDtoAssemblersTest {

    @Test
    void toDto() {
    }

    @Test
    void toDtoList() {
    }

    @Test
    void toEntity() {
    }
}