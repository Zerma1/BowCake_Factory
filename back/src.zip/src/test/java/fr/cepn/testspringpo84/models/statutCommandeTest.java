package fr.cepn.testspringpo84.models;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class statutCommandeTest {

    @Test
    void testEquals() {
    }

    @Test
    void canEqual() {
    }

    @Test
    void testHashCode() {
    }

    @Test
    void testToString() {
    }

    @Test
    void getStaut() {
    }
}