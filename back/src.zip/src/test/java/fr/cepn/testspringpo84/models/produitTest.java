package fr.cepn.testspringpo84.models;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class produitTest {

    @Test
    void testEquals() {
    }

    @Test
    void canEqual() {
    }

    @Test
    void testHashCode() {
    }

    @Test
    void testToString() {
    }

    @Test
    void getNom() {
    }

    @Test
    void getQuantite() {
    }

    @Test
    void getPrix() {
    }

    @Test
    void getPkEtatProduit() {
    }
}