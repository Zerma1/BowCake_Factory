package fr.cepn.testspringpo84.controllers.dtos;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ProduitDtoTest {

    @Test
    void getId() {
    }

    @Test
    void builder() {
    }
}